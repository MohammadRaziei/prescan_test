1. Run python code (Open it in pycharm and run it) 
2. Open PreScan and then open the project
3. Run Matlab within PreScan
4. Run simulation in matlab